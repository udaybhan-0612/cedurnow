import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ArrowLeft, ChevronDown } from "lucide-react"
import { Footer } from "@/components/footer"

export default function FAQPage() {
  const faqs = [
    {
      question: "What is Cedur and how does it work?",
      answer:
        "Cedur is a comprehensive HR management platform designed specifically for Indian businesses. It automates payroll processing, manages employee attendance, handles leave management, and provides tools for employee onboarding. Our cloud-based solution integrates with your existing systems and provides real-time insights into your workforce.",
    },
    {
      question: "Is Cedur compliant with Indian labor laws?",
      answer:
        "Yes, Cedur is fully compliant with Indian labor laws including PF, ESI, PT, LWF, and TDS regulations. We automatically calculate statutory deductions, generate required reports, and help you stay updated with changing compliance requirements.",
    },
    {
      question: "How secure is my data with Cedur?",
      answer:
        "We take data security very seriously. Your data is encrypted both in transit and at rest, stored in secure data centers within India, and we maintain strict access controls. We are ISO 27001 certified and undergo regular security audits.",
    },
    {
      question: "Can I integrate Cedur with my existing systems?",
      answer:
        "Yes, Cedur offers APIs and integrations with popular accounting software, HRMS systems, and banking platforms. We also provide data import tools to help you migrate from your existing systems seamlessly.",
    },
    {
      question: "What kind of support do you provide?",
      answer:
        "We provide 24/7 customer support through phone, email, and chat. Our support team includes HR experts who can help you with both technical issues and HR best practices. We also offer training sessions and onboarding assistance.",
    },
    {
      question: "How much does Cedur cost?",
      answer:
        "We offer flexible pricing plans starting from ₹0 for up to 10 employees. Our paid plans start at ₹23,999 per year for up to 25 employees. All plans include core HR features with higher tiers offering advanced analytics and integrations.",
    },
    {
      question: "Can I try Cedur before purchasing?",
      answer:
        "We offer a 14-day free trial with full access to all features. No credit card required to start your trial. You can also schedule a personalized demo with our team to see how Cedur works for your specific needs.",
    },
    {
      question: "How long does it take to implement Cedur?",
      answer:
        "Most companies are up and running within 1-2 weeks. Our implementation team will help you with data migration, system configuration, and user training. The timeline depends on your company size and complexity of requirements.",
    },
    {
      question: "Do you provide training for my team?",
      answer:
        "Yes, we provide comprehensive training including live sessions, video tutorials, and documentation. Our customer success team ensures your HR team is comfortable using all features before going live.",
    },
    {
      question: "Can I export my data if I decide to leave?",
      answer:
        "Yes, you own your data and can export it at any time. We provide data export tools and will assist you with the process if you decide to discontinue our services.",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center space-x-2">
            <ArrowLeft className="h-5 w-5" />
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center">
                <Image src="/cedur-logo.png" width={32} height={32} alt="Cedur Logo" className="h-8 w-8" />
              </div>
              <span className="text-xl font-bold">Cedur</span>
            </div>
          </Link>
          <Button asChild>
            <Link href="/signup">Get Started</Link>
          </Button>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <Badge variant="secondary">FAQ</Badge>
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Frequently Asked Questions</h1>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Find answers to common questions about Cedur's HR management platform. Can't find what you're looking
                for? Contact our support team.
              </p>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-4xl space-y-4">
              {faqs.map((faq, index) => (
                <Collapsible key={index} className="group">
                  <div className="rounded-lg border bg-white p-6">
                    <CollapsibleTrigger className="flex w-full items-center justify-between text-left">
                      <h3 className="text-lg font-semibold">{faq.question}</h3>
                      <ChevronDown className="h-5 w-5 transition-transform group-data-[state=open]:rotate-180" />
                    </CollapsibleTrigger>
                    <CollapsibleContent className="mt-4">
                      <p className="text-muted-foreground">{faq.answer}</p>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Still have questions?</h2>
              <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed">
                Our support team is here to help. Get in touch and we'll answer any questions you have.
              </p>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" asChild>
                  <Link href="/contact">Contact Support</Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link href="/signup">Start Free Trial</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
