"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, CheckCircle, Users, Mail, Phone } from "lucide-react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { SignInModal } from "@/components/sign-in-modal"
import Image from "next/image"

const getRecommendedPlan = (companySize: string) => {
  switch (companySize) {
    case "1-10":
      return "free"
    case "11-25":
      return "basic"
    case "25-50":
      return "growth"
    case "50-100":
    case "100+":
      return "veteran"
    default:
      return "free"
  }
}

export default function SignupPage() {
  const searchParams = useSearchParams()
  const selectedPlan = searchParams.get("plan") || "free"

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    companySize: "",
    password: "",
    confirmPassword: "",
    agreeToTerms: false,
    subscribeNewsletter: true,
  })

  const [currentStep, setCurrentStep] = useState(1)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [recommendedPlan, setRecommendedPlan] = useState(selectedPlan)
  const [signInModalOpen, setSignInModalOpen] = useState(false)

  const plans = {
    free: { name: "Free", price: "₹0", seats: 10, color: "bg-gray-100" },
    basic: { name: "Basic", price: "₹23,999", seats: 25, color: "bg-yellow-50 border-yellow-200" },
    growth: { name: "Growth", price: "₹39,999", seats: 50, color: "bg-blue-50" },
    veteran: { name: "Veteran", price: "₹69,999", seats: 100, color: "bg-purple-50" },
  }

  const currentPlan = plans[recommendedPlan as keyof typeof plans] || plans.free

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }))

    // Auto-select plan based on company size
    if (field === "companySize" && typeof value === "string") {
      const newPlan = getRecommendedPlan(value)
      setRecommendedPlan(newPlan)
    }

    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.firstName.trim()) newErrors.firstName = "First name is required"
    if (!formData.lastName.trim()) newErrors.lastName = "Last name is required"
    if (!formData.email.trim()) newErrors.email = "Email is required"
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = "Email is invalid"
    if (!formData.phone.trim()) newErrors.phone = "Phone number is required"

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const validateStep2 = () => {
    const newErrors: Record<string, string> = {}

    if (!formData.company.trim()) newErrors.company = "Company name is required"
    if (!formData.companySize) newErrors.companySize = "Company size is required"
    if (!formData.password) newErrors.password = "Password is required"
    else if (formData.password.length < 8) newErrors.password = "Password must be at least 8 characters"
    if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = "Passwords don't match"
    if (!formData.agreeToTerms) newErrors.agreeToTerms = "You must agree to the terms and conditions"

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleNext = () => {
    if (currentStep === 1 && validateStep1()) {
      setCurrentStep(2)
    }
  }

  const handleBack = () => {
    if (currentStep === 2) {
      setCurrentStep(1)
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateStep2()) {
      // Handle signup submission
      console.log("Signup data:", { ...formData, plan: selectedPlan })
      alert(`Welcome to Cedur! Your ${currentPlan.name} plan account has been created successfully.`)
      // In a real app, this would redirect to dashboard or confirmation page
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Modals */}
      <SignInModal isOpen={signInModalOpen} onClose={() => setSignInModalOpen(false)} />
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <ArrowLeft className="h-5 w-5" />
              <div className="flex items-center space-x-2">
                <div className="flex h-8 w-8 items-center justify-center">
                  <Image src="/cedur-logo.png" width={32} height={32} alt="Cedur Logo" className="h-8 w-8" />
                </div>
                <span className="text-xl font-bold">Cedur</span>
              </div>
            </Link>
            <div className="text-sm text-muted-foreground">
              Already have an account?{" "}
              <button onClick={() => setSignInModalOpen(true)} className="text-primary hover:underline">
                Sign in
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Progress Steps */}
          <div className="mb-8">
            <div className="flex items-center justify-center space-x-4">
              <div
                className={`flex items-center space-x-2 ${currentStep >= 1 ? "text-primary" : "text-muted-foreground"}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 1 ? "bg-primary text-white" : "bg-gray-200"}`}
                >
                  1
                </div>
                <span className="font-medium">Personal Info</span>
              </div>
              <div className={`w-16 h-0.5 ${currentStep >= 2 ? "bg-primary" : "bg-gray-200"}`} />
              <div
                className={`flex items-center space-x-2 ${currentStep >= 2 ? "text-primary" : "text-muted-foreground"}`}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center ${currentStep >= 2 ? "bg-primary text-white" : "bg-gray-200"}`}
                >
                  2
                </div>
                <span className="font-medium">Company & Security</span>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Form Section */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Create Your Cedur Account</CardTitle>
                  <CardDescription>
                    {currentStep === 1
                      ? "Let's start with your personal information"
                      : "Complete your company details and secure your account"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {currentStep === 1 && (
                      <>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="firstName">First Name *</Label>
                            <Input
                              id="firstName"
                              value={formData.firstName}
                              onChange={(e) => handleInputChange("firstName", e.target.value)}
                              placeholder="John"
                              className={errors.firstName ? "border-red-500" : ""}
                            />
                            {errors.firstName && <p className="text-sm text-red-500">{errors.firstName}</p>}
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="lastName">Last Name *</Label>
                            <Input
                              id="lastName"
                              value={formData.lastName}
                              onChange={(e) => handleInputChange("lastName", e.target.value)}
                              placeholder="Doe"
                              className={errors.lastName ? "border-red-500" : ""}
                            />
                            {errors.lastName && <p className="text-sm text-red-500">{errors.lastName}</p>}
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="email">Email Address *</Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleInputChange("email", e.target.value)}
                            placeholder="john@company.com"
                            className={errors.email ? "border-red-500" : ""}
                          />
                          {errors.email && <p className="text-sm text-red-500">{errors.email}</p>}
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="phone">Phone Number *</Label>
                          <Input
                            id="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={(e) => handleInputChange("phone", e.target.value)}
                            placeholder="+91 98765 43210"
                            className={errors.phone ? "border-red-500" : ""}
                          />
                          {errors.phone && <p className="text-sm text-red-500">{errors.phone}</p>}
                        </div>

                        <Button type="button" onClick={handleNext} className="w-full">
                          Continue
                        </Button>
                      </>
                    )}

                    {currentStep === 2 && (
                      <>
                        <div className="space-y-2">
                          <Label htmlFor="company">Company Name *</Label>
                          <Input
                            id="company"
                            value={formData.company}
                            onChange={(e) => handleInputChange("company", e.target.value)}
                            placeholder="Your Company Ltd."
                            className={errors.company ? "border-red-500" : ""}
                          />
                          {errors.company && <p className="text-sm text-red-500">{errors.company}</p>}
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="companySize">Company Size *</Label>
                          <Select
                            value={formData.companySize}
                            onValueChange={(value) => handleInputChange("companySize", value)}
                          >
                            <SelectTrigger className={errors.companySize ? "border-red-500" : ""}>
                              <SelectValue placeholder="Select company size" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1-10">1-10 employees</SelectItem>
                              <SelectItem value="11-25">11-25 employees</SelectItem>
                              <SelectItem value="25-50">25-50 employees</SelectItem>
                              <SelectItem value="50-100">50-100 employees</SelectItem>
                              <SelectItem value="100+">100+ employees</SelectItem>
                            </SelectContent>
                          </Select>
                          {errors.companySize && <p className="text-sm text-red-500">{errors.companySize}</p>}
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="password">Password *</Label>
                          <Input
                            id="password"
                            type="password"
                            value={formData.password}
                            onChange={(e) => handleInputChange("password", e.target.value)}
                            placeholder="Create a strong password"
                            className={errors.password ? "border-red-500" : ""}
                          />
                          {errors.password && <p className="text-sm text-red-500">{errors.password}</p>}
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="confirmPassword">Confirm Password *</Label>
                          <Input
                            id="confirmPassword"
                            type="password"
                            value={formData.confirmPassword}
                            onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                            placeholder="Confirm your password"
                            className={errors.confirmPassword ? "border-red-500" : ""}
                          />
                          {errors.confirmPassword && <p className="text-sm text-red-500">{errors.confirmPassword}</p>}
                        </div>

                        <div className="space-y-4">
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="agreeToTerms"
                              checked={formData.agreeToTerms}
                              onCheckedChange={(checked) => handleInputChange("agreeToTerms", checked as boolean)}
                            />
                            <Label htmlFor="agreeToTerms" className="text-sm">
                              I agree to the{" "}
                              <Link href="/terms" className="text-primary hover:underline">
                                Terms of Service
                              </Link>{" "}
                              and{" "}
                              <Link href="/privacy" className="text-primary hover:underline">
                                Privacy Policy
                              </Link>
                              *
                            </Label>
                          </div>
                          {errors.agreeToTerms && <p className="text-sm text-red-500">{errors.agreeToTerms}</p>}

                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id="subscribeNewsletter"
                              checked={formData.subscribeNewsletter}
                              onCheckedChange={(checked) =>
                                handleInputChange("subscribeNewsletter", checked as boolean)
                              }
                            />
                            <Label htmlFor="subscribeNewsletter" className="text-sm">
                              Subscribe to our newsletter for updates and tips
                            </Label>
                          </div>
                        </div>

                        <div className="flex space-x-4">
                          <Button type="button" variant="outline" onClick={handleBack} className="flex-1">
                            Back
                          </Button>
                          <Button type="submit" className="flex-1">
                            Create Account
                          </Button>
                        </div>
                      </>
                    )}
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Plan Summary */}
            <div className="lg:col-span-1">
              <Card className={currentPlan.color}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Selected Plan</CardTitle>
                    {selectedPlan === "basic" && <Badge className="bg-yellow-400 text-black">Recommended</Badge>}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {formData.companySize && recommendedPlan !== selectedPlan && (
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <p className="text-sm text-blue-800">
                        💡 Based on your company size, we recommend the <strong>{currentPlan.name}</strong> plan
                      </p>
                    </div>
                  )}
                  <div>
                    <h3 className="text-2xl font-bold">{currentPlan.name}</h3>
                    <p className="text-3xl font-bold text-primary">
                      {currentPlan.price}
                      <span className="text-lg font-normal text-muted-foreground"> /year</span>
                    </p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <Users className="mr-2 h-4 w-4" />
                      Up to {currentPlan.seats} employees
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                      Payroll Management
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                      Leave Management
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                      Attendance Management
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                      Employee Onboarding
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                      Access & User Management
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <p className="text-sm text-muted-foreground">
                      Want to change your plan?{" "}
                      <Link href="/pricing" className="text-primary hover:underline">
                        View all plans
                      </Link>
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Contact Support */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="text-lg">Need Help?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center text-sm">
                    <Mail className="mr-2 h-4 w-4" />
                    <a href="mailto:info@cedurnow.com" className="text-primary hover:underline">
                      info@cedurnow.com
                    </a>
                  </div>
                  <div className="flex items-center text-sm">
                    <Phone className="mr-2 h-4 w-4" />
                    <a href="tel:011-4345-1244" className="text-primary hover:underline">
                      011-4345-1244
                    </a>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
      <footer id="contact" className="bg-gray-900 text-white">
        <div className="container px-4 py-12 md:px-6">
          <div className="grid gap-8 lg:grid-cols-5">
            {/* Brand Section */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="flex h-8 w-8 items-center justify-center bg-white rounded-lg p-1">
                  <Image src="/cedur-logo.png" width={24} height={24} alt="Cedur Logo" className="h-6 w-6" />
                </div>
                <span className="text-xl font-bold text-white">Cedur</span>
              </div>
              <p className="text-sm text-gray-300">Outthink | Outwork | Outlast</p>
            </div>

            {/* Our Services */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-white">Our Services</h4>
              <ul className="space-y-3 text-sm text-gray-300">
                <li>
                  <Link href="/people-platform" className="hover:text-white transition-colors">
                    People Platform
                  </Link>
                </li>
                <li>
                  <Link href="/payroll" className="hover:text-white transition-colors">
                    Payroll
                  </Link>
                </li>
                <li>
                  <Link href="/hr" className="hover:text-white transition-colors">
                    HR
                  </Link>
                </li>
                <li>
                  <Link href="/attendance" className="hover:text-white transition-colors">
                    Time and Attendance
                  </Link>
                </li>
                <li>
                  <Link href="/hiring" className="hover:text-white transition-colors">
                    Hiring and Onboarding
                  </Link>
                </li>
              </ul>
            </div>

            {/* Company */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-white">Company</h4>
              <ul className="space-y-3 text-sm text-gray-300">
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white transition-colors">
                    Contact Us
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white transition-colors">
                    User Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white transition-colors">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/faq" className="hover:text-white transition-colors">
                    FAQs
                  </Link>
                </li>
              </ul>
            </div>

            {/* Education */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-white">Education</h4>
              <ul className="space-y-3 text-sm text-gray-300">
                <li>
                  <Link href="/blog" className="hover:text-white transition-colors">
                    Blog
                  </Link>
                </li>
              </ul>
            </div>

            {/* Connect with us */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-white">Connect with us</h4>
              <div className="space-y-3 text-sm text-gray-300">
                <div className="flex items-center">
                  <Phone className="mr-2 h-4 w-4" />
                  <div>
                    <div>For Help: 011-4345-1244</div>
                    <div>For Sales: +91-85959 21201</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <Mail className="mr-2 h-4 w-4" />
                  <span>info@cedurnow.com</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
