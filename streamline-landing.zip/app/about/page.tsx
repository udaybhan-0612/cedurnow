import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Users, Target, Award, Heart } from "lucide-react"
import { Footer } from "@/components/footer"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center space-x-2">
            <ArrowLeft className="h-5 w-5" />
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center">
                <Image src="/cedur-logo.png" width={32} height={32} alt="Cedur Logo" className="h-8 w-8" />
              </div>
              <span className="text-xl font-bold">Cedur</span>
            </div>
          </Link>
          <Button asChild>
            <Link href="/signup">Get Started</Link>
          </Button>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <Badge variant="secondary">About Cedur</Badge>
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Outthink | Outwork | Outlast</h1>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                We're on a mission to transform how Indian businesses manage their workforce. Built by HR professionals
                for HR professionals, Cedur combines deep domain expertise with cutting-edge technology.
              </p>
            </div>
          </div>
        </section>

        {/* Story Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter">Our Story</h2>
                <p className="text-muted-foreground md:text-lg">
                  Founded in 2020, Cedur was born from the frustration of dealing with complex, outdated HR systems that
                  didn't understand the unique needs of Indian businesses.
                </p>
                <p className="text-muted-foreground md:text-lg">
                  Our founders, having worked in HR departments across various industries, recognized the need for a
                  solution that was not just powerful, but also intuitive, compliant, and built specifically for the
                  Indian market.
                </p>
                <p className="text-muted-foreground md:text-lg">
                  Today, we serve over 10,000 companies across India, processing more than ₹100 crores in payroll every
                  month, and helping businesses focus on what matters most - their people.
                </p>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  src="/placeholder.svg?height=400&width=500"
                  width={500}
                  height={400}
                  alt="Cedur Team"
                  className="aspect-square overflow-hidden rounded-xl object-cover shadow-lg"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Our Values</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
                The principles that guide everything we do.
              </p>
            </div>
            <div className="grid gap-6 lg:grid-cols-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Users className="h-8 w-8 text-blue-600" />
                    <CardTitle>People First</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    We believe that great businesses are built by great people. Everything we do is designed to help you
                    take better care of your team.
                  </CardDescription>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Target className="h-8 w-8 text-blue-600" />
                    <CardTitle>Innovation</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    We constantly push the boundaries of what's possible in HR technology, bringing you the latest
                    innovations and best practices.
                  </CardDescription>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Award className="h-8 w-8 text-blue-600" />
                    <CardTitle>Excellence</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    We're committed to delivering exceptional quality in everything we do, from our software to our
                    customer support.
                  </CardDescription>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Heart className="h-8 w-8 text-blue-600" />
                    <CardTitle>Integrity</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    We operate with complete transparency and honesty, building trust through our actions and commitment
                    to our customers.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 md:py-16 bg-blue-600 text-primary-foreground">
          <div className="container px-4 md:px-6">
            <div className="grid gap-8 md:grid-cols-4 text-center">
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">10,000+</div>
                <div className="text-sm opacity-90">Companies Trust Us</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">500K+</div>
                <div className="text-sm opacity-90">Employees Managed</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">₹100Cr+</div>
                <div className="text-sm opacity-90">Payroll Processed Monthly</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">99.9%</div>
                <div className="text-sm opacity-90">Uptime Guarantee</div>
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Leadership Team</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
                Meet the people behind Cedur's success.
              </p>
            </div>
            <div className="grid gap-6 lg:grid-cols-3">
              <Card>
                <CardHeader className="text-center">
                  <div className="mx-auto h-24 w-24 rounded-full bg-muted mb-4"></div>
                  <CardTitle>Rajesh Kumar</CardTitle>
                  <CardDescription>CEO & Co-Founder</CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-sm text-muted-foreground">
                    15+ years in HR technology with experience at leading Indian and global companies.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <div className="mx-auto h-24 w-24 rounded-full bg-muted mb-4"></div>
                  <CardTitle>Priya Sharma</CardTitle>
                  <CardDescription>CTO & Co-Founder</CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-sm text-muted-foreground">
                    Former tech lead at major fintech companies, expert in building scalable enterprise solutions.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <div className="mx-auto h-24 w-24 rounded-full bg-muted mb-4"></div>
                  <CardTitle>Amit Patel</CardTitle>
                  <CardDescription>VP of Product</CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-sm text-muted-foreground">
                    Product strategy expert with deep understanding of HR workflows and user experience design.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Join our mission</h2>
              <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed">
                Ready to transform your HR operations? Let's build the future of work together.
              </p>
              <Button size="lg" asChild>
                <Link href="/signup">Start Your Free Trial</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
