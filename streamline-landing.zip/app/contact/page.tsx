import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Mail, Phone, Clock, Handshake, Users, TrendingUp } from "lucide-react"
import { Footer } from "@/components/footer"

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center space-x-2">
            <ArrowLeft className="h-5 w-5" />
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center">
                <Image src="/cedur-logo.png" width={32} height={32} alt="Cedur Logo" className="h-8 w-8" />
              </div>
              <span className="text-xl font-bold">Cedur</span>
            </div>
          </Link>
          <Button asChild>
            <Link href="/signup">Get Started</Link>
          </Button>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <Badge variant="secondary">Contact Us</Badge>
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Get in Touch with Our Team</h1>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Have questions about Cedur? Want to schedule a demo? Our team is here to help you find the perfect HR
                solution for your business.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Form & Info Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              {/* Contact Form */}
              <Card>
                <CardHeader>
                  <CardTitle>Send us a message</CardTitle>
                  <CardDescription>Fill out the form below and we'll get back to you within 24 hours.</CardDescription>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input id="firstName" placeholder="John" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input id="lastName" placeholder="Doe" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input id="email" type="email" placeholder="john@company.com" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="company">Company</Label>
                      <Input id="company" placeholder="Your Company" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input id="phone" type="tel" placeholder="+91 98765 43210" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="message">Message</Label>
                      <Textarea id="message" placeholder="Tell us about your requirements..." rows={4} />
                    </div>
                    <Button type="submit" className="w-full">
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Contact Information</CardTitle>
                    <CardDescription>Reach out to us through any of these channels.</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <Mail className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium">Email</p>
                        <p className="text-sm text-muted-foreground">info@cedurnow.com</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Phone className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium">Phone</p>
                        <p className="text-sm text-muted-foreground">
                          Help: 011-4345-1244
                          <br />
                          Sales: +91-85959 21201
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Clock className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium">Business Hours</p>
                        <p className="text-sm text-muted-foreground">
                          Monday - Friday: 9:00 AM - 6:00 PM IST
                          <br />
                          Saturday: 10:00 AM - 2:00 PM IST
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/signup">
                        <Mail className="mr-2 h-4 w-4" />
                        Start Free Trial
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/#pricing">
                        <Phone className="mr-2 h-4 w-4" />
                        View Pricing
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full justify-start" asChild>
                      <Link href="/faq">
                        <Clock className="mr-2 h-4 w-4" />
                        View FAQs
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Become a Partner Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <Badge variant="secondary">Partnership</Badge>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Become a Cedur Partner</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
                Join our growing network of partners and explore opportunities to help businesses transform their HR
                operations while building a partnership with Cedur.
              </p>
            </div>
            <div className="grid gap-6 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Handshake className="h-8 w-8 text-blue-600" />
                    <CardTitle>Reseller Partner</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    Explore opportunities to become an authorized reseller and help sell Cedur's HR solutions to your
                    clients.
                  </CardDescription>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Commission-based partnership model</li>
                    <li>• Dedicated partner support</li>
                    <li>• Sales training and materials</li>
                    <li>• Co-marketing opportunities</li>
                  </ul>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Users className="h-8 w-8 text-blue-600" />
                    <CardTitle>Implementation Partner</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    Join our network of implementation specialists and help businesses implement and customize Cedur
                    solutions.
                  </CardDescription>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Implementation service opportunities</li>
                    <li>• Technical training and certification</li>
                    <li>• Priority technical support</li>
                    <li>• Customer referral programs</li>
                  </ul>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <TrendingUp className="h-8 w-8 text-blue-600" />
                    <CardTitle>Technology Partner</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    Explore integration opportunities with Cedur's platform and create combined offerings for mutual
                    customers.
                  </CardDescription>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• API access and documentation</li>
                    <li>• Joint go-to-market possibilities</li>
                    <li>• Technical integration support</li>
                    <li>• Co-branded marketing materials</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
            <div className="flex flex-col items-center justify-center space-y-4 text-center mt-12">
              <h3 className="text-2xl font-bold">Interested in Partnering with Us?</h3>
              <p className="max-w-[600px] text-muted-foreground">
                Join our network of partners who are exploring opportunities to grow their business with Cedur. Let's
                discuss possibilities together.
              </p>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" asChild>
                  <Link href="mailto:partners@cedurnow.com">Inquire About Partnership</Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link href="/signup">Learn More</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Support Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Need immediate help?</h2>
              <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed">
                Our support team is available 24/7 to help you with any questions or issues.
              </p>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" asChild>
                  <Link href="tel:01143451244">Call Support</Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link href="https://wa.me/918595921201">WhatsApp Us</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
