"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, CheckCircle, Zap, Shield, Users, BarChart3, Star } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { EnquiryModal } from "@/components/enquiry-modal"
import { SignInModal } from "@/components/sign-in-modal"
import { DemoModal } from "@/components/demo-modal"
import { Footer } from "@/components/footer"

export default function LandingPage() {
  const [enquiryModalOpen, setEnquiryModalOpen] = useState(false)
  const [signInModalOpen, setSignInModalOpen] = useState(false)
  const [demoModalOpen, setDemoModalOpen] = useState(false)

  // Show enquiry modal when site opens
  useEffect(() => {
    const timer = setTimeout(() => {
      setEnquiryModalOpen(true)
    }, 2000) // Show after 2 seconds

    return () => clearTimeout(timer)
  }, [])

  const handleGetStarted = () => {
    window.location.href = "/signup"
  }

  const handleStartFreeTrial = () => {
    alert("Starting free trial! This would typically redirect to /trial-signup")
  }

  const handleGoToDashboard = (plan: string) => {
    window.location.href = `/signup?plan=${plan.toLowerCase()}`
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Modals */}
      <EnquiryModal isOpen={enquiryModalOpen} onClose={() => setEnquiryModalOpen(false)} />
      <SignInModal isOpen={signInModalOpen} onClose={() => setSignInModalOpen(false)} />
      <DemoModal isOpen={demoModalOpen} onClose={() => setDemoModalOpen(false)} />

      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center space-x-2">
            <div className="flex h-8 w-8 items-center justify-center">
              <Image src="/cedur-logo.png" width={32} height={32} alt="Cedur Logo" className="h-8 w-8" />
            </div>
            <span className="text-xl font-bold">Cedur</span>
          </div>

          <nav className="hidden md:flex items-center space-x-6">
            <Link href="#features" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Features
            </Link>
            <Link href="#testimonials" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Testimonials
            </Link>
            <Link href="#pricing" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Pricing
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Contact
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              className="hidden sm:inline-flex"
              onClick={() => setSignInModalOpen(true)}
            >
              Sign In
            </Button>
            <Button size="sm" onClick={handleGetStarted}>
              Get Started
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <Badge variant="secondary" className="w-fit">
                    🚀 New: AI-Powered Workflows
                  </Badge>
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Streamline Your Workflow, Amplify Your Success
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Revolutionize your HR operations with India's most trusted payroll and workforce management
                    platform. Automate payroll, streamline attendance, and empower your employees with seamless digital
                    experiences.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button size="lg" className="h-12 px-8" onClick={handleStartFreeTrial}>
                    Start Free Trial
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="lg"
                    className="h-12 px-8 bg-white text-black"
                    onClick={() => setDemoModalOpen(true)}
                  >
                    Watch Demo
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  src="/cedur-dashboard.png"
                  width={600}
                  height={400}
                  alt="Cedur Dashboard - HR Management Platform"
                  className="w-full h-auto rounded-xl shadow-2xl border"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 md:py-16 bg-blue-600 text-primary-foreground">
          <div className="container px-4 md:px-6">
            <div className="grid gap-8 md:grid-cols-4 text-center">
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">10,000+</div>
                <div className="text-sm opacity-90">Companies Trust Us</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">500K+</div>
                <div className="text-sm opacity-90">Employees Managed</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">99.9%</div>
                <div className="text-sm opacity-90">Uptime Guarantee</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">₹100Cr+</div>
                <div className="text-sm opacity-90">Payroll Processed</div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge variant="secondary">Features</Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Features that make payroll easy</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Comprehensive HR solutions designed to simplify your workforce management and streamline operations.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-2 lg:gap-12">
              <div className="grid gap-6">
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600">
                        <Users className="h-5 w-5 text-primary-foreground" />
                      </div>
                      <CardTitle>Fast & Easy On-Boarding</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      Streamline new employee onboarding with digital forms, automated workflows, and seamless
                      integration with your existing systems.
                    </CardDescription>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600">
                        <BarChart3 className="h-5 w-5 text-primary-foreground" />
                      </div>
                      <CardTitle>Intuitive Attendance Management</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      Track employee attendance with smart biometric integration, real-time monitoring, and automated
                      reporting for better workforce insights.
                    </CardDescription>
                  </CardContent>
                </Card>
              </div>
              <div className="grid gap-6">
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600">
                        <Zap className="h-5 w-5 text-primary-foreground" />
                      </div>
                      <CardTitle>Robust Payroll</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      Automated payroll processing with tax calculations, compliance management, and seamless
                      integration with banking systems for error-free payments.
                    </CardDescription>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600">
                        <Shield className="h-5 w-5 text-primary-foreground" />
                      </div>
                      <CardTitle>Payslips for Everyone</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      Generate and distribute digital payslips instantly with detailed breakdowns, tax deductions, and
                      secure employee portal access.
                    </CardDescription>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge variant="secondary">How It Works</Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Get started in 3 simple steps</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Setting up your HR management system has never been easier. Follow these simple steps to get your team
                  up and running.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-8 py-12 lg:grid-cols-3">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600/10">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-primary-foreground font-bold">
                    1
                  </div>
                </div>
                <h3 className="text-xl font-bold">Sign Up & Setup</h3>
                <p className="text-muted-foreground">
                  Create your account, add your company details, and invite your team members in minutes.
                </p>
              </div>
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600/10">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-primary-foreground font-bold">
                    2
                  </div>
                </div>
                <h3 className="text-xl font-bold">Configure & Customize</h3>
                <p className="text-muted-foreground">
                  Set up your payroll rules, attendance policies, and customize the system to match your company needs.
                </p>
              </div>
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600/10">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-primary-foreground font-bold">
                    3
                  </div>
                </div>
                <h3 className="text-xl font-bold">Go Live & Manage</h3>
                <p className="text-muted-foreground">
                  Start managing your HR processes seamlessly with automated workflows and real-time insights.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section id="testimonials" className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge variant="secondary">Testimonials</Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Loved by teams worldwide</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  See what our customers have to say about Cedur.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3 lg:gap-12">
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <blockquote className="text-lg">
                    "Cedur has transformed how our team works. We've increased productivity by 40% and reduced manual
                    work significantly."
                  </blockquote>
                  <div className="mt-4">
                    <div className="font-semibold">Sarah Johnson</div>
                    <div className="text-sm text-muted-foreground">VP of Operations, TechCorp</div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <blockquote className="text-lg">
                    "The AI automation features are incredible. Tasks that used to take hours now complete in minutes."
                  </blockquote>
                  <div className="mt-4">
                    <div className="font-semibold">Michael Chen</div>
                    <div className="text-sm text-muted-foreground">CTO, StartupXYZ</div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                </CardHeader>
                <CardContent>
                  <blockquote className="text-lg">
                    "Best investment we've made for our team. The collaboration features are game-changing."
                  </blockquote>
                  <div className="mt-4">
                    <div className="font-semibold">Emily Rodriguez</div>
                    <div className="text-sm text-muted-foreground">Project Manager, DesignStudio</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Why Choose Cedur Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <Badge variant="secondary">Why Choose Cedur</Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                  Built for Indian businesses, trusted by thousands
                </h2>
                <p className="text-muted-foreground md:text-lg">
                  Cedur understands the unique challenges of Indian HR management. From compliance with local labor laws
                  to integration with Indian banking systems, we've got you covered.
                </p>
                <div className="grid gap-4 mt-6">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">100% Compliant</h4>
                      <p className="text-sm text-muted-foreground">
                        Fully compliant with Indian labor laws, PF, ESI, and tax regulations
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Bank Integration</h4>
                      <p className="text-sm text-muted-foreground">
                        Direct integration with major Indian banks for seamless salary transfers
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">24/7 Support</h4>
                      <p className="text-sm text-muted-foreground">
                        Dedicated support team available in Hindi and English
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Data Security</h4>
                      <p className="text-sm text-muted-foreground">
                        Enterprise-grade security with data centers in India
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  src="/cedur-payroll-dashboard.png"
                  width={600}
                  height={400}
                  alt="Cedur Payroll Dashboard - Employee Management Interface"
                  className="w-full h-auto rounded-xl shadow-lg border max-w-[600px]"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <Badge variant="secondary">Pricing</Badge>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Simple, transparent pricing</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Choose the plan that's right for your team. Start with our free plan and upgrade as you grow.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-6xl items-center gap-6 py-12 lg:grid-cols-4 lg:gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Free</CardTitle>
                  <div className="text-3xl font-bold">
                    ₹0<span className="text-lg font-normal"> - Yearly</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="text-sm text-muted-foreground">Total Seats Available (10)</div>
                    <ul className="space-y-2 text-sm">
                      <li>Payroll Management</li>
                      <li>Leave Management</li>
                      <li>Attendance Management</li>
                      <li>Employee Onboarding</li>
                      <li>Access & User Management</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <Button
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      onClick={() => handleGoToDashboard("Free")}
                    >
                      Go To Dashboard
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-yellow-400 relative">
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-yellow-400 text-black font-semibold px-4 py-1">Recommended By Cedur</Badge>
                </div>
                <CardHeader className="pt-6">
                  <CardTitle>Basic</CardTitle>
                  <div className="text-3xl font-bold">
                    ₹23,999<span className="text-lg font-normal"> - Yearly</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="text-sm text-muted-foreground">Total Seats Available (25)</div>
                    <ul className="space-y-2 text-sm">
                      <li>Payroll Management</li>
                      <li>Leave Management</li>
                      <li>Attendance Management</li>
                      <li>Employee Onboarding</li>
                      <li>Access & User Management</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <Button
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      onClick={() => handleGoToDashboard("Basic")}
                    >
                      Go To Dashboard
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Growth</CardTitle>
                  <div className="text-3xl font-bold">
                    ₹39,999<span className="text-lg font-normal"> - Yearly</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="text-sm text-muted-foreground">Total Seats Available (50)</div>
                    <ul className="space-y-2 text-sm">
                      <li>Payroll Management</li>
                      <li>Leave Management</li>
                      <li>Attendance Management</li>
                      <li>Employee Onboarding</li>
                      <li>Access & User Management</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <Button
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      onClick={() => handleGoToDashboard("Growth")}
                    >
                      Go To Dashboard
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Veteran</CardTitle>
                  <div className="text-3xl font-bold">
                    ₹69,999<span className="text-lg font-normal"> - Yearly</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="text-sm text-muted-foreground">Total Seats Available (100)</div>
                    <ul className="space-y-2 text-sm">
                      <li>Payroll Management</li>
                      <li>Leave Management</li>
                      <li>Attendance Management</li>
                      <li>Employee Onboarding</li>
                      <li>Access & User Management</li>
                    </ul>
                  </div>
                  <div className="space-y-2">
                    <Button
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      onClick={() => handleGoToDashboard("Veteran")}
                    >
                      Go To Dashboard
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Integration Section */}

        {/* Final CTA Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Ready to streamline your workflow?</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Join thousands of teams who have transformed their productivity with Cedur. Start your free trial
                  today.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" className="h-12 px-8" onClick={handleStartFreeTrial}>
                  Start Free Trial
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="h-12 px-8 bg-white text-black"
                  onClick={() => setDemoModalOpen(true)}
                >
                  Schedule Demo
                </Button>
              </div>
              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <div className="flex items-center">
                  <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                  14-day free trial
                </div>
                <div className="flex items-center">
                  <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                  No setup fees
                </div>
                <div className="flex items-center">
                  <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                  Cancel anytime
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
