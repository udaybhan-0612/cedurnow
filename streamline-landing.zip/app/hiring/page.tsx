import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Users, FileText, CheckCircle, Calendar, Mail, Zap } from "lucide-react"
import { Footer } from "@/components/footer"

export default function HiringPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center space-x-2">
            <ArrowLeft className="h-5 w-5" />
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center">
                <Image src="/cedur-logo.png" width={32} height={32} alt="Cedur Logo" className="h-8 w-8" />
              </div>
              <span className="text-xl font-bold">Cedur</span>
            </div>
          </Link>
          <Button asChild>
            <Link href="/signup">Get Started</Link>
          </Button>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <Badge variant="secondary">Hiring & Onboarding</Badge>
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">
                Streamlined Hiring & Seamless Onboarding
              </h1>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                From job posting to first day success. Manage your entire recruitment process and create exceptional
                onboarding experiences that set new hires up for success.
              </p>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" asChild>
                  <Link href="/signup">Start Free Trial</Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link href="/#contact">Schedule Demo</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Complete Hiring Solution</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
                Everything you need to attract, evaluate, and onboard the best talent.
              </p>
            </div>
            <div className="grid gap-6 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Users className="h-8 w-8 text-blue-600" />
                    <CardTitle>Applicant Tracking</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Manage job postings, track applications, and streamline your recruitment pipeline with automated
                    workflows.
                  </CardDescription>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-8 w-8 text-blue-600" />
                    <CardTitle>Interview Scheduling</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Automated interview scheduling with calendar integration, candidate notifications, and feedback
                    collection.
                  </CardDescription>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <FileText className="h-8 w-8 text-blue-600" />
                    <CardTitle>Digital Onboarding</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Paperless onboarding with digital forms, document collection, and automated task assignments.
                  </CardDescription>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="h-8 w-8 text-blue-600" />
                    <CardTitle>Background Verification</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Integrated background checks, reference verification, and compliance documentation management.
                  </CardDescription>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Mail className="h-8 w-8 text-blue-600" />
                    <CardTitle>Communication Hub</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Centralized communication with candidates, automated email templates, and status updates.
                  </CardDescription>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <Zap className="h-8 w-8 text-blue-600" />
                    <CardTitle>Workflow Automation</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription>
                    Automate repetitive tasks, approval processes, and notifications to speed up hiring decisions.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Process Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Hiring made simple</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
                From posting jobs to welcoming new team members, we've streamlined every step.
              </p>
            </div>
            <div className="mx-auto grid max-w-6xl items-center gap-8 py-12 lg:grid-cols-4">
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600/10">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-primary-foreground font-bold">
                    1
                  </div>
                </div>
                <h3 className="text-xl font-bold">Post & Promote</h3>
                <p className="text-muted-foreground text-sm">
                  Create job postings and distribute across multiple job boards and social platforms.
                </p>
              </div>
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600/10">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-primary-foreground font-bold">
                    2
                  </div>
                </div>
                <h3 className="text-xl font-bold">Screen & Select</h3>
                <p className="text-muted-foreground text-sm">
                  Review applications, conduct interviews, and collaborate with your team on hiring decisions.
                </p>
              </div>
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600/10">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-primary-foreground font-bold">
                    3
                  </div>
                </div>
                <h3 className="text-xl font-bold">Verify & Approve</h3>
                <p className="text-muted-foreground text-sm">
                  Complete background checks, reference verification, and get final approvals.
                </p>
              </div>
              <div className="flex flex-col items-center text-center space-y-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-blue-600/10">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-600 text-primary-foreground font-bold">
                    4
                  </div>
                </div>
                <h3 className="text-xl font-bold">Onboard & Welcome</h3>
                <p className="text-muted-foreground text-sm">
                  Digital onboarding with document collection, system access, and welcome workflows.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tighter">Why choose Cedur for hiring?</h2>
                <p className="text-muted-foreground md:text-lg">
                  Reduce time-to-hire, improve candidate experience, and make better hiring decisions with data-driven
                  insights.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-1" />
                    <div>
                      <h4 className="font-semibold">50% Faster Hiring</h4>
                      <p className="text-sm text-muted-foreground">
                        Streamlined processes reduce average time-to-hire significantly
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-1" />
                    <div>
                      <h4 className="font-semibold">Better Candidate Experience</h4>
                      <p className="text-sm text-muted-foreground">
                        Modern, mobile-friendly application and communication process
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-1" />
                    <div>
                      <h4 className="font-semibold">Compliance Ready</h4>
                      <p className="text-sm text-muted-foreground">
                        Built-in compliance with Indian labor laws and documentation requirements
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  src="/placeholder.svg?height=400&width=500"
                  width={500}
                  height={400}
                  alt="Hiring Dashboard"
                  className="aspect-square overflow-hidden rounded-xl object-cover shadow-lg"
                />
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">
                Ready to transform your hiring process?
              </h2>
              <p className="max-w-[600px] text-blue-100 md:text-xl/relaxed">
                Join companies who have revolutionized their recruitment and onboarding with Cedur.
              </p>
              <Button size="lg" variant="secondary" asChild>
                <Link href="/signup">Start Your Free Trial</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
