import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calculator, Shield, FileText, Clock, CheckCircle, IndianRupee } from "lucide-react"
import { Footer } from "@/components/footer"

export default function PayrollPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center space-x-2">
            <ArrowLeft className="h-5 w-5" />
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center">
                <Image src="/cedur-logo.png" width={32} height={32} alt="Cedur Logo" className="h-8 w-8" />
              </div>
              <span className="text-xl font-bold">Cedur</span>
            </div>
          </Link>
          <Button asChild>
            <Link href="/signup">Get Started</Link>
          </Button>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <Badge variant="secondary">Payroll Management</Badge>
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">
                Automated Payroll Processing Made Simple
              </h1>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Process payroll in minutes, not hours. Our automated system handles complex calculations, tax
                compliance, and direct bank transfers with 100% accuracy.
              </p>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" asChild>
                  <Link href="/signup">Start Free Trial</Link>
                </Button>
                <Button variant="outline" size="lg" asChild>
                  <Link href="/#contact">Schedule Demo</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Calculator className="h-8 w-8 text-blue-600" />
                      <CardTitle>Automated Calculations</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      Automatic calculation of salary, overtime, bonuses, deductions, PF, ESI, and tax with zero errors.
                    </CardDescription>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Shield className="h-8 w-8 text-blue-600" />
                      <CardTitle>Tax Compliance</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      Stay compliant with Indian tax laws, TDS calculations, and automatic generation of Form 16.
                    </CardDescription>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <IndianRupee className="h-8 w-8 text-blue-600" />
                      <CardTitle>Bank Integration</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      Direct integration with major Indian banks for seamless salary transfers and payment processing.
                    </CardDescription>
                  </CardContent>
                </Card>
              </div>
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <FileText className="h-8 w-8 text-blue-600" />
                      <CardTitle>Digital Payslips</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      Generate and distribute secure digital payslips with detailed breakdowns and tax information.
                    </CardDescription>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-8 w-8 text-blue-600" />
                      <CardTitle>Multi-frequency Payroll</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      Support for monthly, bi-weekly, weekly payroll cycles with flexible pay structures.
                    </CardDescription>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-8 w-8 text-blue-600" />
                      <CardTitle>Statutory Compliance</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>
                      Automatic PF, ESI, PT, and LWF calculations with government filing support.
                    </CardDescription>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-12 md:py-16 bg-blue-600 text-primary-foreground">
          <div className="container px-4 md:px-6">
            <div className="grid gap-8 md:grid-cols-4 text-center">
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">₹100Cr+</div>
                <div className="text-sm opacity-90">Payroll Processed Monthly</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">99.9%</div>
                <div className="text-sm opacity-90">Accuracy Rate</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">5 Min</div>
                <div className="text-sm opacity-90">Average Processing Time</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl md:text-4xl font-bold">24/7</div>
                <div className="text-sm opacity-90">Support Available</div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Ready to automate your payroll?</h2>
              <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed">
                Join thousands of companies who have simplified their payroll with Cedur.
              </p>
              <Button size="lg" asChild>
                <Link href="/signup">Start Your Free Trial</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
