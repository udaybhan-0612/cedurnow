import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Calendar, User, ArrowRight } from "lucide-react"
import { Footer } from "@/components/footer"

export default function BlogPage() {
  const blogPosts = [
    {
      title: "Complete Guide to Payroll Management in India 2024",
      excerpt:
        "Everything you need to know about payroll compliance, tax calculations, and best practices for Indian businesses.",
      author: "Priya Sharma",
      date: "December 15, 2024",
      category: "Payroll",
      readTime: "8 min read",
    },
    {
      title: "10 HR Trends That Will Shape 2025",
      excerpt:
        "Discover the latest HR trends including AI automation, remote work policies, and employee experience innovations.",
      author: "Rajesh Kumar",
      date: "December 10, 2024",
      category: "HR Trends",
      readTime: "6 min read",
    },
    {
      title: "How to Build an Effective Employee Onboarding Process",
      excerpt:
        "Step-by-step guide to creating onboarding experiences that improve retention and accelerate productivity.",
      author: "Amit Patel",
      date: "December 5, 2024",
      category: "Onboarding",
      readTime: "10 min read",
    },
    {
      title: "Understanding PF, ESI, and Other Statutory Compliances",
      excerpt: "A comprehensive guide to Indian statutory compliances every HR professional should know.",
      author: "Neha Singh",
      date: "November 28, 2024",
      category: "Compliance",
      readTime: "12 min read",
    },
    {
      title: "Digital Transformation in HR: A Practical Approach",
      excerpt: "How to modernize your HR processes and leverage technology for better employee experiences.",
      author: "Vikram Gupta",
      date: "November 20, 2024",
      category: "Digital HR",
      readTime: "7 min read",
    },
    {
      title: "Performance Management Best Practices for Growing Teams",
      excerpt: "Implement effective performance management systems that drive growth and employee engagement.",
      author: "Sunita Reddy",
      date: "November 15, 2024",
      category: "Performance",
      readTime: "9 min read",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center space-x-2">
            <ArrowLeft className="h-5 w-5" />
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center">
                <Image src="/cedur-logo.png" width={32} height={32} alt="Cedur Logo" className="h-8 w-8" />
              </div>
              <span className="text-xl font-bold">Cedur</span>
            </div>
          </Link>
          <Button asChild>
            <Link href="/signup">Get Started</Link>
          </Button>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <Badge variant="secondary">Blog</Badge>
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">HR Insights & Best Practices</h1>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Stay updated with the latest HR trends, compliance updates, and best practices. Learn from industry
                experts and grow your HR knowledge.
              </p>
            </div>
          </div>
        </section>

        {/* Featured Post */}
        <section className="py-12 md:py-16 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-4xl">
              <Badge className="mb-4">Featured Post</Badge>
              <Card className="overflow-hidden">
                <div className="grid lg:grid-cols-2">
                  <div className="aspect-video lg:aspect-square bg-muted"></div>
                  <CardHeader className="lg:p-8">
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-2">
                      <Badge variant="outline">Payroll</Badge>
                      <span>•</span>
                      <span>8 min read</span>
                    </div>
                    <CardTitle className="text-2xl lg:text-3xl">
                      Complete Guide to Payroll Management in India 2024
                    </CardTitle>
                    <CardDescription className="text-base">
                      Everything you need to know about payroll compliance, tax calculations, and best practices for
                      Indian businesses. This comprehensive guide covers all aspects of modern payroll management.
                    </CardDescription>
                    <div className="flex items-center space-x-4 pt-4">
                      <div className="flex items-center space-x-2">
                        <User className="h-4 w-4" />
                        <span className="text-sm">Priya Sharma</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar className="h-4 w-4" />
                        <span className="text-sm">December 15, 2024</span>
                      </div>
                    </div>
                    <Button className="w-fit mt-4">
                      Read Article
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </CardHeader>
                </div>
              </Card>
            </div>
          </div>
        </section>

        {/* Blog Posts Grid */}
        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Latest Articles</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed">
                Discover insights, tips, and strategies to improve your HR operations.
              </p>
            </div>
            <div className="grid gap-6 lg:grid-cols-3">
              {blogPosts.map((post, index) => (
                <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="aspect-video bg-muted"></div>
                  <CardHeader>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-2">
                      <Badge variant="outline">{post.category}</Badge>
                      <span>•</span>
                      <span>{post.readTime}</span>
                    </div>
                    <CardTitle className="line-clamp-2">{post.title}</CardTitle>
                    <CardDescription className="line-clamp-3">{post.excerpt}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <User className="h-3 w-3" />
                          <span>{post.author}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-3 w-3" />
                          <span>{post.date}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        Read More
                        <ArrowRight className="ml-1 h-3 w-3" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Newsletter Section */}
        <section className="py-12 md:py-24 lg:py-32 bg-blue-600 text-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Stay Updated</h2>
              <p className="max-w-[600px] text-blue-100 md:text-xl/relaxed">
                Subscribe to our newsletter and get the latest HR insights delivered to your inbox.
              </p>
              <div className="w-full max-w-md space-y-2">
                <div className="flex space-x-2">
                  <input
                    type="email"
                    placeholder="Enter your email"
                    className="flex-1 px-3 py-2 rounded-md text-black"
                  />
                  <Button variant="secondary">Subscribe</Button>
                </div>
                <p className="text-xs text-blue-200">No spam. Unsubscribe at any time.</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
