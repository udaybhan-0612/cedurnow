import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft } from "lucide-react"
import { Footer } from "@/components/footer"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center space-x-2">
            <ArrowLeft className="h-5 w-5" />
            <div className="flex items-center space-x-2">
              <div className="flex h-8 w-8 items-center justify-center">
                <Image src="/cedur-logo.png" width={32} height={32} alt="Cedur Logo" className="h-8 w-8" />
              </div>
              <span className="text-xl font-bold">Cedur</span>
            </div>
          </Link>
          <Button asChild>
            <Link href="/signup">Get Started</Link>
          </Button>
        </div>
      </header>

      <main>
        <div className="container px-4 py-12 md:px-6">
          <div className="mx-auto max-w-4xl space-y-8">
            <div className="text-center space-y-4">
              <Badge variant="secondary">Legal</Badge>
              <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Terms of Service</h1>
              <p className="text-muted-foreground">Last updated: December 2024</p>
            </div>

            <div className="prose prose-gray max-w-none space-y-8">
              <section>
                <h2 className="text-2xl font-bold mb-4">1. Acceptance of Terms</h2>
                <p className="text-muted-foreground">
                  By accessing and using Cedur's services, you accept and agree to be bound by the terms and provision
                  of this agreement.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">2. Description of Service</h2>
                <p className="text-muted-foreground mb-4">
                  Cedur provides cloud-based HR management software including:
                </p>
                <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                  <li>Payroll processing and management</li>
                  <li>Employee attendance tracking</li>
                  <li>Leave management systems</li>
                  <li>HR analytics and reporting</li>
                  <li>Employee onboarding tools</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">3. User Responsibilities</h2>
                <p className="text-muted-foreground mb-4">As a user of our services, you agree to:</p>
                <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                  <li>Provide accurate and complete information</li>
                  <li>Maintain the security of your account credentials</li>
                  <li>Use the service in compliance with applicable laws</li>
                  <li>Not misuse or abuse the platform</li>
                  <li>Respect intellectual property rights</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">4. Payment Terms</h2>
                <p className="text-muted-foreground mb-4">Payment terms for our services:</p>
                <ul className="list-disc pl-6 space-y-2 text-muted-foreground">
                  <li>Subscription fees are billed annually in advance</li>
                  <li>All prices are in Indian Rupees (INR)</li>
                  <li>Refunds are subject to our refund policy</li>
                  <li>Late payments may result in service suspension</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">5. Data Ownership</h2>
                <p className="text-muted-foreground">
                  You retain ownership of all data you input into our system. We provide tools for data export and
                  maintain backups for service continuity.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">6. Service Availability</h2>
                <p className="text-muted-foreground">
                  We strive to maintain 99.9% uptime but cannot guarantee uninterrupted service. Scheduled maintenance
                  will be communicated in advance.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">7. Limitation of Liability</h2>
                <p className="text-muted-foreground">
                  Our liability is limited to the amount paid for our services. We are not liable for indirect,
                  incidental, or consequential damages.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">8. Termination</h2>
                <p className="text-muted-foreground">
                  Either party may terminate this agreement with 30 days written notice. Upon termination, you will have
                  90 days to export your data.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">9. Governing Law</h2>
                <p className="text-muted-foreground">
                  These terms are governed by the laws of India. Any disputes will be resolved in the courts of
                  Gurugram, Haryana.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-4">10. Contact Information</h2>
                <p className="text-muted-foreground">For questions about these terms, contact us at:</p>
                <div className="bg-muted p-4 rounded-lg mt-4">
                  <p className="font-medium">Cedur Technologies Pvt. Ltd.</p>
                  <p className="text-muted-foreground">Email: legal@cedurnow.com</p>
                  <p className="text-muted-foreground">Phone: 011-4345-1244</p>
                </div>
              </section>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
