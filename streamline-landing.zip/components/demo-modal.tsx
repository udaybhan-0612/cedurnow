"use client"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Play, ExternalLink } from "lucide-react"

interface DemoModalProps {
  isOpen: boolean
  onClose: () => void
}

export function DemoModal({ isOpen, onClose }: DemoModalProps) {
  const handleWatchDemo = () => {
    // Redirect to YouTube tutorial
    window.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ", "_blank")
    onClose()
  }

  const handleScheduleDemo = () => {
    // In a real app, this would open a calendar booking system
    alert("Calendar booking system would open here (like Calendly integration)!")
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Play className="h-5 w-5" />
            Watch Cedur in Action
          </DialogTitle>
          <DialogDescription>
            See how Cedur can transform your team's productivity with our interactive demo.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-6">
          <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
            <div className="text-center space-y-2">
              <Play className="h-12 w-12 mx-auto text-muted-foreground" />
              <p className="text-sm text-muted-foreground">Demo Video Placeholder</p>
            </div>
          </div>
          <div className="grid gap-3">
            <Button onClick={handleWatchDemo} className="w-full">
              <Play className="mr-2 h-4 w-4" />
              Watch 3-Minute Demo
            </Button>
            <Button onClick={handleScheduleDemo} variant="outline" className="w-full">
              <ExternalLink className="mr-2 h-4 w-4" />
              Schedule Live Demo
            </Button>
          </div>
          <div className="text-center">
            <Button variant="ghost" onClick={onClose}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
